class PrinterDevice {
  final String name;
  final String address;

  PrinterDevice({required this.name, required this.address});
}
